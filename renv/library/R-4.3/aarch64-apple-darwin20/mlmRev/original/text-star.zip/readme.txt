Project STAR
Tennessee's Class-Size Study
Public Access Data Set for 
kindergarten through third grade 


Display Dictionary
File Information


---------------------------------------------------------------------------------
 | Output Created                               | 30 October 1998                | 
 |------------ | ------------------------------ | -------------------------------| 
 | Input       | Data                           | webstar.txt (Tab-delimited)    | 
 |             | ------------------------------ | -------------------------------| 
 |             | Filter                         | <none>                         | 
 |             | ------------------------------ | -------------------------------| 
 |             | Weight                         | <none>                         | 
 |             | ------------------------------ | -------------------------------| 
 |             | Split File                     | <none>                         | 
 |             | ------------------------------ | -------------------------------| 
 |             | N of Rows in Working Data File | 11598                          | 
 |------------ | ------------------------------ | -------------------------------| 
 | Syntax                                       | DISPLAY DICTIONARY.            | 
 |------------ | ------------------------------ | -------------------------------| 
 | Resources   | Elapsed Time                   | 0:00:00.22                     | 
 |------------ | ------------------------------ | -------------------------------| 



List of variables on the data file

Name                                                                   Position

NEWID     New Student ID for public star datasets                             1
          Measurement Level: Scale
          Column Width: 7  Alignment: Center
          Print Format: F6
          Write Format: F6
          Missing Values: 999999

          Value    Label

         999999 M  Missing (should not be missing)

SSEX      Student Sex   (1M2F)                                                2
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    MALE
              2    FEMALE
              9 M  Missing

SRACE     Student Race  (1W2B3A4H5I6O)                                        3
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    WHITE
              2    BLACK
              3    ASIAN
              4    HISPANIC
              5    AM. INDIAN
              6    OTHER
              9 M  Missing


SBIRTHQ   Quater of students birth                                            4
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F2
          Write Format: F2
          Missing Values: 99

          Value    Label

              1    1st qtr - jan,feb,march
              2    2nd qtr - april,may,june
              3    3rd qtr - july,aug,sept
              4    4th qtr - oct,nov,dec
             99 M  Missing

SBIRTHY   Year of students birth                                              5
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F4
          Write Format: F4
          Missing Values: 9999

          Value    Label

           9999 M  Missing

STARK     Attend Project STAR Class In KINDERGARTEN                           6
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    YES
              2    NO
              9 M  Missing (should not be missing)

STAR1     Attend Project STAR Class In 1ST GRADE                              7
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    YES
              2    NO
              9 M  Missing (should not be missing)



STAR2     Attend Project STAR Class In 2ND GRADE                              8
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    YES
              2    NO
              9 M  Missing (should not be missing)

STAR3     Attend Project STAR Class In 3RD GRADE                              9
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    YES
              2    NO
              9 M  Missing (should not be missing)

CLTYPEK   Classroom Type  (1S2R3RA) in KINDERGARTEN                          10
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    SMALL CLASS
              2    REGULAR CLASS
              3    REGULAR + AIDE CLASS
              9 M  Missing


CLTYPE1   Classroom Type  (1S2R3RA) in FIRST GRADE                           11
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    SMALL CLASS
              2    REGULAR CLASS
              3    REGULAR + AIDE CLASS
              9 M  Missing

CLTYPE2   Classroom Type  (1S2R3RA) in SECOND GRADE                          12
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    SMALL CLASS
              2    REGULAR CLASS
              3    REGULAR + AIDE CLASS
              9 M  Missing

CLTYPE3   Classroom Type  (1S2R3RA) in THIRD GRADE                           13
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    SMALL CLASS
              2    REGULAR CLASS
              3    REGULAR + AIDE CLASS
              9 M  Missing


SCHTYPEK  School Type - (1I2S3R4U) in KINDERGARTEN                           14
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    INNER-CITY
              2    SUBURBAN SCHOOL
              3    RURAL SCHOOL
              4    URBAN SCHOOL
              9 M  Missing

HDEGK     Highest Degree (tch) of KINDERGARTEN Teacher                       15
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    ASSOCIATES
              2    BACHELORS
              3    MASTERS
              4    MASTER +
              5    SPECIALIST
              6    DOCTORAL
              9 M  MISSING

CLADK     Teacher Career Ladder Level in KINDERGARTEN                        16
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    LEVEL 1
              2    LEVEL 2
              3    LEVEL 3
              5    APPRENTICE
              6    PROBATIONARY
              7    NOT ON CAREER LADDER
              8    PENDING
              9 M  MISSING


TOTEXPK   Years of Total Teaching Experience - KINDERGARTEN                  17
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F2
          Write Format: F2
          Missing Values: 99

          Value    Label

              0    First year teacher
             99 M  Missing

TRACEK    Teacher Race  (1W2B3A4H5I6O) in KINDERGARTEN                       18
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    WHITE
              2    BLACK
              3    ASIAN
              4    HISPANIC
              5    AM. INDIAN
              6    OTHER
              9 M  Missing

TREADSSK  Total Reading Scaled Score - SESAT II STANFORD                     19
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

TMATHSSK  Total Math Scaled Score - SESAT II STANFORD                        20
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999



SESK      Socio-Economic Status in KINDERGARTEN                              21
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    FREE LUNCH
              2    NON-FREE LUNCH
              9 M  Missing

SCHTYPE1  School Type - (1I2S3R4U) in FIRST GRADE                            22
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    INNER-CITY
              2    SUBURBAN SCHOOL
              3    RURAL SCHOOL
              4    URBAN SCHOOL
              9 M  Missing

TRACE1    Teacher Race  (1W2B3A4H5I6O) in 1st GRADE                          23
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    WHITE
              2    BLACK
              3    ASIAN
              4    HISPANIC
              5    AM. INDIAN
              6    OTHER
              9 M  Missing


HDEG1     Highest Degree (tch) of 1st GRADE Teacher                          24
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    BACHELORS  (BS/BA)
              2    MASTERS    (MS/MA/Med)
              3    SPECIALIST (Ed.S)
              4    DOCTORAL   (Ed.S/Ph.D)
              9 M  MISSING

CLAD1     Teacher Career Ladder Level in 1ST GRADE                           25
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    CHOSE NO TO BE ON CAREER LADDER
              2    APPRENTICE
              3    PROBATION
              4    LADDER LEVEL 1
              5    LEVEL 2
              6    LEVEL 3
              9 M  Missing

TOTEXP1   Years of Total Teaching Experience - 1ST GRADE                     26
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F2
          Write Format: F2
          Missing Values: 99

          Value    Label

              0    First year teacher
             99 M  Missing

TREADSS1  Total Reading Scaled Score - PRIMARY 1 STANFORD                    27
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999


TMATHSS1  Total Math Scaled Score - PRIMARY 1 STANFORD                       28
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

SES1      Socio-Economic Status in 1ST GRADE                                 29
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    FREE LUNCH
              2    NON-FREE LUNCH
              9 M  Missing

SCHTYPE2  School Type - (1I2S3R4U) in 2ND GRADE                              30
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    INNER-CITY
              2    SUBURBAN SCHOOL
              3    RURAL SCHOOL
              4    URBAN SCHOOL
              9 M  Missing

TRACE2    Teacher Race  (1W2B3A4H5I6O) in 2nd GRADE                          31
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    WHITE
              2    BLACK
              3    ASIAN
              4    HISPANIC
              5    AM. INDIAN
              6    OTHER
              9 M  Missing


HDEG2     Highest Degree (tch) of 2ND GRADE Teacher                          32
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    BACHELORS  (BS/BA)
              2    MASTERS    (MS/MA/Med)
              3    SPECIALIST (Ed.S)
              4    DOCTORAL   (Ed.S/Ph.D)
              9 M  MISSING

CLAD2     Teacher Career Ladder Level in 2ND GRADE                           33
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    CHOSE NO TO BE ON CAREER LADDER
              2    APPRENTICE
              3    PROBATION
              4    LADDER LEVEL 1
              5    LEVEL 2
              6    LEVEL 3
              9 M  Missing

TOTEXP2   Years of Total Teaching Experience - 2ND GRADE                     34
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F2
          Write Format: F2
          Missing Values: 99

          Value    Label

              0    First year teacher
             99 M  Missing

TREADSS2  Total Reading Scaled Score - PRIMARY 2 STANFORD                    35
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999


TMATHSS2  Total Math Scaled Score - PRIMARY 2 STANFORD                       36
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

SES2      Socio-Economic Status in 2ND GRADE                                 37
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    FREE LUNCH
              2    NON-FREE LUNCH
              9 M  Missing

SCHTYPE3  School Type - (1I2S3R4U) in THIRD GRADE                            38
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    INNER-CITY
              2    SUBURBAN SCHOOL
              3    RURAL SCHOOL
              4    URBAN SCHOOL
              9 M  Missing

TREADSS3  Total Reading Scaled Score - PRIMARY 3 STANFORD                    39
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

TMATHSS3  Total Math Scaled Score - PRIMARY 3 STANFORD                       40
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999


SES3      Socio-Economic Status in 3RD GRADE                                 41
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    FREE LUNCH
              2    NON-FREE LUNCH
              9 M  Missing

TRACE3    Teacher Race  (1W2B3A4H5I6O) in 3RD GRADE                          42
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    WHITE
              2    BLACK
              3    ASIAN
              4    HISPANIC
              5    AM. INDIAN
              6    OTHER
              9 M  Missing

HDEG3     Highest Degree (tch) of 3rd GRADE Teacher                          43
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    BACHELORS  (BS/BA)
              2    MASTERS    (MS/MA/Med)
              3    SPECIALIST (Ed.S)
              4    DOCTORAL   (Ed.S/Ph.D)
              9 M  MISSING


CLAD3     Teacher Career Ladder Level in 3rd GRADE                           44
          Measurement Level: Ordinal
          Column Width: Unknown  Alignment: Right
          Print Format: F1
          Write Format: F1
          Missing Values: 9

          Value    Label

              1    CHOSE NO TO BE ON CAREER LADDER
              2    APPRENTICE
              3    PROBATION
              4    LADDER LEVEL 1
              5    LEVEL 2
              6    LEVEL 3
              9 M  Missing

TOTEXP3   Years of Total Teaching Experience -  3RD GRADE                    45
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F2
          Write Format: F2
          Missing Values: 99

          Value    Label

              0    First year teacher
             99 M  Missing

SYSIDKN   sch system ID-K (new) kindergarten                                 46
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

          Value    Label

            999 M  Missing

SYSID1N   sch system ID-G1 (new) 1st grade                                   47
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

          Value    Label

            999 M  Missing


SYSID2N   sch system ID-G2 (new) 2nd grade                                   48
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

          Value    Label

            999 M  Missing

SYSID3N   sch system ID-G3 (new) 3rd grade                                   49
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

          Value    Label

            999 M  Missing

SCHIDKN   school ID-K (new) kindergarten                                     50
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

          Value    Label

            999 M  Missing

SCHID1N   school ID-G1 (new) 1st grade                                       51
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

          Value    Label

            999 M  Missing


SCHID2N   school ID-G2 (new) 2nd grade                                       52
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

          Value    Label

            999 M  Missing

SCHID3N   school ID-G3 (new) 3rd grade                                       53
          Measurement Level: Scale
          Column Width: Unknown  Alignment: Right
          Print Format: F3
          Write Format: F3
          Missing Values: 999

          Value    Label

            999 M  Missing




Data Map.

Variable: NEWID      Type: Number   Width:  6   Dec: 0
Variable: SSEX       Type: Number   Width:  1   Dec: 0
Variable: SRACE      Type: Number   Width:  1   Dec: 0
Variable: SBIRTHQ    Type: Number   Width:  2   Dec: 0
Variable: SBIRTHY    Type: Number   Width:  4   Dec: 0
Variable: STARK      Type: Number   Width:  1   Dec: 0
Variable: STAR1      Type: Number   Width:  1   Dec: 0
Variable: STAR2      Type: Number   Width:  1   Dec: 0
Variable: STAR3      Type: Number   Width:  1   Dec: 0
Variable: CLTYPEK    Type: Number   Width:  1   Dec: 0
Variable: CLTYPE1    Type: Number   Width:  1   Dec: 0
Variable: CLTYPE2    Type: Number   Width:  1   Dec: 0
Variable: CLTYPE3    Type: Number   Width:  1   Dec: 0
Variable: SCHTYPEK   Type: Number   Width:  1   Dec: 0
Variable: HDEGK      Type: Number   Width:  1   Dec: 0
Variable: CLADK      Type: Number   Width:  1   Dec: 0
Variable: TOTEXPK    Type: Number   Width:  2   Dec: 0
Variable: TRACEK     Type: Number   Width:  1   Dec: 0
Variable: TREADSSK   Type: Number   Width:  3   Dec: 0
Variable: TMATHSSK   Type: Number   Width:  3   Dec: 0
Variable: SESK       Type: Number   Width:  1   Dec: 0
Variable: SCHTYPE1   Type: Number   Width:  1   Dec: 0
Variable: TRACE1     Type: Number   Width:  1   Dec: 0
Variable: HDEG1      Type: Number   Width:  1   Dec: 0
Variable: CLAD1      Type: Number   Width:  1   Dec: 0
Variable: TOTEXP1    Type: Number   Width:  2   Dec: 0
Variable: TREADSS1   Type: Number   Width:  3   Dec: 0
Variable: TMATHSS1   Type: Number   Width:  3   Dec: 0
Variable: SES1       Type: Number   Width:  1   Dec: 0
Variable: SCHTYPE2   Type: Number   Width:  1   Dec: 0
Variable: TRACE2     Type: Number   Width:  1   Dec: 0
Variable: HDEG2      Type: Number   Width:  1   Dec: 0
Variable: CLAD2      Type: Number   Width:  1   Dec: 0
Variable: TOTEXP2    Type: Number   Width:  2   Dec: 0
Variable: TREADSS2   Type: Number   Width:  3   Dec: 0
Variable: TMATHSS2   Type: Number   Width:  3   Dec: 0
Variable: SES2       Type: Number   Width:  1   Dec: 0
Variable: SCHTYPE3   Type: Number   Width:  1   Dec: 0
Variable: TREADSS3   Type: Number   Width:  3   Dec: 0
Variable: TMATHSS3   Type: Number   Width:  3   Dec: 0
Variable: SES3       Type: Number   Width:  1   Dec: 0
Variable: TRACE3     Type: Number   Width:  1   Dec: 0
Variable: HDEG3      Type: Number   Width:  1   Dec: 0
Variable: CLAD3      Type: Number   Width:  1   Dec: 0
Variable: TOTEXP3    Type: Number   Width:  2   Dec: 0
Variable: SYSIDKN    Type: Number   Width:  3   Dec: 0
Variable: SYSID1N    Type: Number   Width:  3   Dec: 0
Variable: SYSID2N    Type: Number   Width:  3   Dec: 0
Variable: SYSID3N    Type: Number   Width:  3   Dec: 0
Variable: SCHIDKN    Type: Number   Width:  3   Dec: 0
Variable: SCHID1N    Type: Number   Width:  3   Dec: 0
Variable: SCHID2N    Type: Number   Width:  3   Dec: 0
Variable: SCHID3N    Type: Number   Width:  3   Dec: 0

53 variables and 11598 cases written.

On November 1, 1998, Health & Education Research Operative Services, 
(HEROS), Incorporated released the Project STAR (kindergarten to third 
grade) public access data set. The release of this data to the research 
community is intended to facilitate further discussion of the effects 
of reduced class size in education.  This data set includes student 
achievement data from the four years that Project STAR operated as well 
as student and teacher demographic data. All personal information that 
could be used to identify individual students and teachers has been 
removed. Over the next two years, additional research data from Project 
STAR and the STAR Follow-up Studies will be appended to the public 
access data set. 